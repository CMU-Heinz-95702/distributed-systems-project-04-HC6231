package ds.forexcnoverter;

//Author Haoran Chen - haoranc3
import java.util.Date;

public class LoggingModel {
    // Simple nested classes for structure
    public static class ForexLog {
        private String requestId;
        private Date timestamp;
        private String deviceInfo;
        private String fromCurrency;
        private String toCurrency;
        private double amount;
        private double exchangeRate;
        private int responseCode;
        private long responseTime;
        private String error;

        // Constructor
        public ForexLog(String requestId) {
            this.requestId = requestId;
            this.timestamp = new Date();
        }

        // Getters and Setters
        public String getRequestId() { return requestId; }
        public Date getTimestamp() { return timestamp; }
        public String getDeviceInfo() { return deviceInfo; }
        public void setDeviceInfo(String deviceInfo) { this.deviceInfo = deviceInfo; }
        public String getFromCurrency() { return fromCurrency; }
        public void setFromCurrency(String fromCurrency) { this.fromCurrency = fromCurrency; }
        public String getToCurrency() { return toCurrency; }
        public void setToCurrency(String toCurrency) { this.toCurrency = toCurrency; }
        public double getAmount() { return amount; }
        public void setAmount(double amount) { this.amount = amount; }
        public double getExchangeRate() { return exchangeRate; }
        public void setExchangeRate(double exchangeRate) { this.exchangeRate = exchangeRate; }
        public int getResponseCode() { return responseCode; }
        public void setResponseCode(int responseCode) { this.responseCode = responseCode; }
        public long getResponseTime() { return responseTime; }
        public void setResponseTime(long responseTime) { this.responseTime = responseTime; }
        public String getError() { return error; }
        public void setError(String error) { this.error = error; }
    }
}