package ds.forexcnoverter;
//Author Haoran Chen - haoranc3

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoException;
import com.mongodb.ServerApi;
import com.mongodb.ServerApiVersion;
import com.mongodb.client.*;
import org.bson.Document;
import java.util.*;

public class MongoDBService {
    private final MongoClient mongoClient;
    private final MongoCollection<Document> logsCollection;

    public MongoDBService() {
        String connectionString = "mongodb+srv://haoranc3:Djk7iJRjIFTmol0I@cluster0.ctex7.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

        try {
            // Configure the MongoDB connection
            ServerApi serverApi = ServerApi.builder()
                    .version(ServerApiVersion.V1)
                    .build();

            MongoClientSettings settings = MongoClientSettings.builder()
                    .applyConnectionString(new ConnectionString(connectionString))
                    .serverApi(serverApi)
                    .build();

            // Create the client
            mongoClient = MongoClients.create(settings);

            // Test the connection
            MongoDatabase adminDb = mongoClient.getDatabase("admin");
            adminDb.runCommand(new Document("ping", 1));
            System.out.println("Successfully connected to MongoDB!");

            // Get the forex database and collection
            MongoDatabase forexDb = mongoClient.getDatabase("forex_logs");
            logsCollection = forexDb.getCollection("forex_logs");

        } catch (MongoException e) {
            System.err.println("MongoDB Connection Error: " + e.getMessage());
            throw new RuntimeException("Failed to connect to MongoDB", e);
        }
    }

    public void logRequest(LoggingModel.ForexLog log) {
        try {
            Document doc = new Document()
                    .append("requestId", log.getRequestId())
                    .append("timestamp", log.getTimestamp())
                    .append("deviceInfo", log.getDeviceInfo())
                    .append("fromCurrency", log.getFromCurrency())
                    .append("toCurrency", log.getToCurrency())
                    .append("amount", log.getAmount())
                    .append("exchangeRate", log.getExchangeRate())
                    .append("responseCode", log.getResponseCode())
                    .append("responseTime", log.getResponseTime())
                    .append("error", log.getError());

            logsCollection.insertOne(doc);
            System.out.println("Successfully logged request: " + log.getRequestId());
        } catch (MongoException e) {
            System.err.println("Error logging request: " + e.getMessage());
        }
    }

    public List<Document> getRecentLogs(int limit) {
        List<Document> logs = new ArrayList<>();
        try {
            logsCollection.find()
                    .sort(new Document("timestamp", -1))
                    .limit(limit)
                    .into(logs);
        } catch (MongoException e) {
            System.err.println("Error retrieving logs: " + e.getMessage());
        }
        return logs;
    }

    public Document getStats() {
        Document stats = new Document();
        try {
            // Basic statistics
            long totalRequests = logsCollection.countDocuments();
            stats.append("totalRequests", totalRequests);

            // Average response time and success rate
            List<Document> pipeline = Arrays.asList(
                    new Document("$group", new Document()
                            .append("_id", null)
                            .append("avgResponseTime", new Document("$avg", "$responseTime"))
                            .append("successRate", new Document("$avg", new Document(
                                    "$cond", Arrays.asList(
                                    new Document("$eq", Arrays.asList("$responseCode", 200)),
                                    1,
                                    0
                            )
                            )))
                    )
            );

            Document aggregateResult = logsCollection.aggregate(pipeline).first();
            if (aggregateResult != null) {
                stats.putAll(aggregateResult);
            }
        } catch (MongoException e) {
            System.err.println("Error calculating stats: " + e.getMessage());
            stats.append("error", e.getMessage());
        }
        return stats;
    }

    // Method to properly close MongoDB connection
    @Override
    protected void finalize() throws Throwable {
        try {
            if (mongoClient != null) {
                mongoClient.close();
                System.out.println("MongoDB connection closed");
            }
        } finally {
            super.finalize();
        }
    }
}