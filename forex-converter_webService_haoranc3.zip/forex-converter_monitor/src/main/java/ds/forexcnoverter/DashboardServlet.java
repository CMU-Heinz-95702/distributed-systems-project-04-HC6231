//Author Haoran Chen - haoranc3
package ds.forexcnoverter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.bson.Document;
import java.io.IOException;
import java.util.List;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    private MongoDBService mongoDBService;

    @Override
    public void init() throws ServletException {
        super.init();
        try {
            mongoDBService = new MongoDBService();
            System.out.println("DashboardServlet: MongoDB service initialized");
        } catch (Exception e) {
            System.err.println("DashboardServlet: Failed to initialize MongoDB service");
            throw new ServletException("Failed to initialize MongoDB service", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            // Get statistics
            Document stats = mongoDBService.getStats();
            System.out.println("DashboardServlet: Retrieved stats: " + stats.toJson());

            // Get recent logs (last 20 entries)
            List<Document> recentLogs = mongoDBService.getRecentLogs(20);
            System.out.println("DashboardServlet: Retrieved " + recentLogs.size() + " recent logs");

            // Set attributes for JSP
            request.setAttribute("stats", stats);
            request.setAttribute("recentLogs", recentLogs);

            // Forward to dashboard JSP - Update this path to match your structure
            request.getRequestDispatcher("/WEB-INF/dashboard.jsp").forward(request, response);

        } catch (Exception e) {
            System.err.println("Error in dashboard servlet: " + e.getMessage());
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Error loading dashboard: " + e.getMessage());
        }
    }
}