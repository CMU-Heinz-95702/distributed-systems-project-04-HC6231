package ds.forexcnoverter;
//Author Haoran Chen - haoranc3

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

@WebServlet("/convert")
public class ForexServlet extends HttpServlet {
    private final Gson gson = new Gson();
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(10))
            .build();
    private MongoDBService mongoDBService;
    private static final String API_KEY = "46184ca73cca58b24e987ca7";
    private static final String API_BASE_URL = "https://v6.exchangerate-api.com/v6/";

    @Override
    public void init() throws ServletException {
        super.init();
        mongoDBService = new MongoDBService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Enable CORS
        setupCORS(response);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        long startTime = System.currentTimeMillis();
        LoggingModel.ForexLog log = new LoggingModel.ForexLog(java.util.UUID.randomUUID().toString());
        log.setDeviceInfo(request.getHeader("User-Agent"));

        try {
            String fromCurrency = request.getParameter("from");
            String toCurrency = request.getParameter("to");
            String amountStr = request.getParameter("amount");

            if (fromCurrency == null || toCurrency == null || amountStr == null) {
                handleError(response, log, "Missing parameters", 400);
                return;
            }

            double amount;
            try {
                amount = Double.parseDouble(amountStr);
            } catch (NumberFormatException e) {
                handleError(response, log, "Invalid amount format", 400);
                return;
            }

            // Set log data
            log.setFromCurrency(fromCurrency);
            log.setToCurrency(toCurrency);
            log.setAmount(amount);

            // Get exchange rate
            String url = String.format("%s%s/pair/%s/%s",
                    API_BASE_URL, API_KEY,
                    fromCurrency.toUpperCase(),
                    toCurrency.toUpperCase());

            HttpRequest apiRequest = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> apiResponse = httpClient.send(apiRequest,
                    HttpResponse.BodyHandlers.ofString());

            if (apiResponse.statusCode() != 200) {
                handleError(response, log, "API Error", apiResponse.statusCode());
                return;
            }

            // Process successful response
            double rate = parseExchangeRate(apiResponse.body());
            double result = amount * rate;

            log.setExchangeRate(rate);
            log.setResponseCode(200);
            log.setResponseTime(System.currentTimeMillis() - startTime);

            // Send response
            String jsonResponse = gson.toJson(new ConversionResult(
                    fromCurrency, toCurrency, amount, result, rate));
            response.getWriter().write(jsonResponse);

            // Log successful request
            mongoDBService.logRequest(log);

        } catch (Exception e) {
            handleError(response, log, "Internal server error: " + e.getMessage(), 500);
        }
    }

    private void handleError(HttpServletResponse response, LoggingModel.ForexLog log,
                             String message, int statusCode) throws IOException {
        log.setResponseCode(statusCode);
        log.setError(message);
        log.setResponseTime(System.currentTimeMillis() - log.getTimestamp().getTime());
        mongoDBService.logRequest(log);

        response.setStatus(statusCode);
        response.getWriter().write(gson.toJson(new ErrorResponse(message)));
    }

    private double parseExchangeRate(String apiResponse) {
        return gson.fromJson(apiResponse, ApiResponse.class).conversion_rate;
    }

    private void setupCORS(HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
    }

    private static class ConversionResult {
        private final String from;
        private final String to;
        private final double amount;
        private final double result;
        private final double rate;

        public ConversionResult(String from, String to, double amount,
                                double result, double rate) {
            this.from = from;
            this.to = to;
            this.amount = amount;
            this.result = result;
            this.rate = rate;
        }
    }

    private static class ErrorResponse {
        private final String error;

        public ErrorResponse(String error) {
            this.error = error;
        }
    }

    private static class ApiResponse {
        private double conversion_rate;
    }
}